// Place third party dependencies in the lib folder
//
// Configure loading modules from the lib directory,
// except 'app' ones, 

// Load the main app module to start the app
requirejs(["config/main"]);