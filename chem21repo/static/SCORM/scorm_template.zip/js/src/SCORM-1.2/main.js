define(['jquery'], function ($) {

   function findAPI(win)
   {
      var findAPITries = 0;
      // Check to see if the window (win) contains the API
      // if the window (win) does not contain the API and
      // the window (win) has a parent window and the parent window
      // is not the same as the window (win)
      while ( (win.API == null) &&
              (win.parent != null) &&
              (win.parent != win) )
      {
         // increment the number of findAPITries
         findAPITries++;

         // Note: 7 is an arbitrary number, but should be more than sufficient
         if (findAPITries > 7)
         {
            alert("Error finding API -- too deeply nested.");
            return null;
         }

         // set the variable that represents the window being
         // being searched to be the parent of the current window
         // then search for the API again
         win = win.parent;
      }
      return win.API;
   }

   function getAPI()
   {
      // start by looking for the API in the current window
      var theAPI = findAPI(window);

      // if the API is null (could not be found in the current window)
      // and the current window has an opener window
      if ( (theAPI == null) &&
           (window.opener != null) &&
           (typeof(window.opener) != "undefined") )
      {
         // try to find the API in the current window’s opener
         theAPI = findAPI(window.opener);
      }
      // if the API has not been found
      if (theAPI == null)
      {
         // Alert the user that the API Adapter could not be found
         alert("Unable to find an API adapter");
      }
      return theAPI;
   }


   //Create function handlers for the loading and unloading of the page


   //Constants
   var SCORM_TRUE = "true";
   var SCORM_FALSE = "false";
   var SCORM_NO_ERROR = "0";

   //Since the Unload handler will be called twice, from both the onunload
   //and onbeforeunload events, ensure that we only call LMSFinish once.
   var finishCalled = false;

   //Track whether or not we successfully initialized.
   var initialized = false;
   var start_time = null;

   var API = null;
   var LMS = null;

   function ZeroPad(intNum, intNumDigits){
 
       var strTemp;
       var intLen;
       var i;
      
       strTemp = new String(intNum);
       intLen = strTemp.length;
      
       if (intLen > intNumDigits){
          strTemp = strTemp.substr(0,intNumDigits);
       }
       else{
          for (i=intLen; i<intNumDigits; i++){
             strTemp = "0" + strTemp;
          }
       }
      
       return strTemp;
    }

    //SCORM requires time to be formatted in a specific way
    function ConvertMilliSecondsToSCORMTime(intTotalMilliseconds, blnIncludeFraction){
   
       var intHours;
       var intintMinutes;
       var intSeconds;
       var intMilliseconds;
       var intHundredths;
       var strCMITimeSpan;
      
       if (blnIncludeFraction == null || blnIncludeFraction == undefined){
          blnIncludeFraction = true;
       }
      
       //extract time parts
       intMilliseconds = intTotalMilliseconds % 1000;

       intSeconds = ((intTotalMilliseconds - intMilliseconds) / 1000) % 60;

       intMinutes = ((intTotalMilliseconds - intMilliseconds - (intSeconds * 1000)) / 60000) % 60;

       intHours = (intTotalMilliseconds - intMilliseconds - (intSeconds * 1000) - (intMinutes * 60000)) / 3600000;

       /*
       deal with exceptional case when content used a huge amount of time and interpreted CMITimstamp 
       to allow a number of intMinutes and seconds greater than 60 i.e. 9999:99:99.99 instead of 9999:60:60:99
       note - this case is permissable under SCORM, but will be exceptionally rare
       */

       if (intHours == 10000) 
       { 
          intHours = 9999;

          intMinutes = (intTotalMilliseconds - (intHours * 3600000)) / 60000;
          if (intMinutes == 100) 
          {
             intMinutes = 99;
          }
          intMinutes = Math.floor(intMinutes);
         
          intSeconds = (intTotalMilliseconds - (intHours * 3600000) - (intMinutes * 60000)) / 1000;
          if (intSeconds == 100) 
          {
             intSeconds = 99;
          }
          intSeconds = Math.floor(intSeconds);
         
          intMilliseconds = (intTotalMilliseconds - (intHours * 3600000) - (intMinutes * 60000) - (intSeconds * 1000));
       }

       //drop the extra precision from the milliseconds
       intHundredths = Math.floor(intMilliseconds / 10);

       //put in padding 0's and concatinate to get the proper format
       strCMITimeSpan = ZeroPad(intHours, 4) + ":" + ZeroPad(intMinutes, 2) + ":" + ZeroPad(intSeconds, 2);
      
       if (blnIncludeFraction){
          strCMITimeSpan += "." + intHundredths;
       }

       //check for case where total milliseconds is greater than max supported by strCMITimeSpan
       if (intHours > 9999) 
       {
          strCMITimeSpan = "9999:99:99";
         
          if (blnIncludeFraction){
             strCMITimeSpan += ".99";
          }
       }

       return strCMITimeSpan;
      
    }

   function ProcessInitialize(){
       var result;
       start_time = new Date();

       
       API = getAPI();
       
       if (API == null){
           alert("ERROR - Could not establish a connection with the LMS.\n\nYour results may not be recorded.");
           return;
       }
       
       result = API.LMSInitialize("");
       
       if (result == SCORM_FALSE){
           var errorNumber = API.LMSGetLastError();
           var errorString = API.LMSGetErrorString(errorNumber);
           var diagnostic = API.LMSGetDiagnostic(errorNumber);
           
           var errorDescription = "Number: " + errorNumber + "\nDescription: " + errorString + "\nDiagnostic: " + diagnostic;
           
           alert("Error - Could not initialize communication with the LMS.\n\nYour results may not be recorded.\n\n" + errorDescription);
           return;
       }
       LMS.value("cmi.core.exit", "suspend");
       LMS.status("incomplete");

       initialized = true;

   }

   function ProcessSetElapsedTime() {
       //record the session time
     var endTimeStamp = new Date();
     var startTimeStamp = start_time;
     var totalMilliseconds = (endTimeStamp.getTime() - startTimeStamp.getTime());
     var scormTime = ConvertMilliSecondsToSCORMTime(totalMilliseconds, false);
     LMS.value("cmi.core.session_time", scormTime);
   }

   function ProcessFinish(complete, suspend){
      // defaults to suspending as incomplete
      // complete process cannot suspend
     if( complete === undefined) {
       complete = false;
     }
     if (complete ) {
       suspend = false;
     }
     if (suspend === undefined)  {
         suspend = true;
     }
       
     var result;
     
     if (suspend) {
       // save data
       console.debug("Suspending!");
       LMS.value("cmi.core.exit", "suspend");
       LMS.status("incomplete");
     }
     if (complete) {
       console.debug("Finished!");
       LMS.status("completed");
     }

     ProcessSetElapsedTime();  
     result = API.LMSFinish("");
     
     if (result == SCORM_FALSE){
         var errorNumber = API.LMSGetLastError();
         var errorString = API.LMSGetErrorString(errorNumber);
         var diagnostic = API.LMSGetDiagnostic(errorNumber);
         
         var errorDescription = "Number: " + errorNumber + "\nDescription: " + errorString + "\nDiagnostic: " + diagnostic;
         
         alert("Error - Could not terminate communication with the LMS.\n\nYour results may not be recorded.\n\n" + errorDescription);
         return;
     }
   }

   function ProcessGetValue(element){
    
    var result;
    
    if (initialized == false || finishCalled == true){return;}
    
    result = API.LMSGetValue(element);
    
    if (result == ""){
    
        var errorNumber = API.LMSGetLastError();
        
        if (errorNumber != SCORM_NO_ERROR){
            var errorString = API.LMSGetErrorString(errorNumber);
            var diagnostic = API.LMSGetDiagnostic(errorNumber);
            
            var errorDescription = "Number: " + errorNumber + "\nDescription: " + errorString + "\nDiagnostic: " + diagnostic;
            
            alert("Error - Could not retrieve a value from the LMS.\n\n" + errorDescription);
            return "";
        }
    }
    
    return result;
   }

   function ProcessSetValue(element, value){
      
       var result;
       if (initialized == false || finishCalled == true){return;}
       result = API.LMSSetValue(element, value);
       
       if (result == SCORM_FALSE){
           var errorNumber = API.LMSGetLastError();
           var errorString = API.LMSGetErrorString(errorNumber);
           var diagnostic = API.LMSGetDiagnostic(errorNumber);
           
           var errorDescription = "Number: " + errorNumber + "\nDescription: " + errorString + "\nDiagnostic: " + diagnostic;
           
           alert("Error - Could not store a value in the LMS.\n\nYour results may not be recorded.\n\n" + errorDescription);
           return;
       }
       
   }

   function ProcessValue(element, value) {
      if( value === undefined) {
         return ProcessGetValue( element );
      } else {
         return ProcessSetValue( element, value );
      }
   }

   function Bookmark(value) {
      return LMS.value("cmi.core.lesson_location", value);
   }

   function Status(value) {
      return LMS.value("cmi.core.lesson_status", value);
   }

    function RecordMulti(id, questionText, learnerResponse, score){
      //Interactions are stored in a collection. We need to find the number of items currently in
      //the collection so we can store this question in the next bucket.
      //Since the collection indicies are 0-based, the count will be the identifier for the next
      //available bucket.
      var nextIndex = ProcessValue("cmi.interactions._count");
      //question id must be the first item set
      ProcessValue("cmi.interactions." + nextIndex + ".id", id);
      //Use the question text as the interaction's description
      ProcessValue("cmi.interactions." + nextIndex + ".description", questionText);
      //The question type should be set before detailed response information
      ProcessValue("cmi.interactions." + nextIndex + ".type", "performance");
      if (learnerResponse) {
          learnerResponse = learnerResponse.join();
          //Record the response the learner gave (if one was provided)
          ProcessValue("cmi.interactions." + nextIndex + ".learner_response", learnerResponse);
      }      
      ProcessValue("cmi.interactions." + nextIndex + ".result", score);
    }

    function RecordSingle(id, questionText, learnerResponse, correctAnswer, wasCorrect) {   
      var nextIndex = ProcessValue("cmi.interactions._count");
      ProcessValue("cmi.interactions." + nextIndex + ".id", id);     
      ProcessValue("cmi.interactions." + nextIndex + ".type", "choice");
      if (learnerResponse != ""){
          //Record the response the learner gave (if one was provided)
          ProcessValue("cmi.interactions." + nextIndex + ".learner_response", learnerResponse);
          if(wasCorrect) {
            ProcessValue("cmi.interactions." + nextIndex + ".result", "correct");
          } else {
            ProcessValue("cmi.interactions." + nextIndex + ".result", "incorrect");
          }
      } else {
          ProcessValue("cmi.interactions." + nextIndex + ".result", "neutral");
      }
    }

    function RecordReveal(id) {
      var nextIndex = ProcessValue("cmi.interactions._count");
      ProcessValue("cmi.interactions." + nextIndex + ".id", id);     
      ProcessValue("cmi.interactions." + nextIndex + ".type", "true-false");
      ProcessValue("cmi.interactions." + nextIndex + ".result", 1);
    }

    function RecordPageComplete(id) {
      var nextIndex = ProcessValue("cmi.interactions._count");
      ProcessValue("cmi.interactions." + nextIndex + ".id", id);     
      ProcessValue("cmi.interactions." + nextIndex + ".type", "true-false");
      ProcessValue("cmi.interactions." + nextIndex + ".result", 1);
    }

    function GetProgress() {
      var count = ProcessValue("cmi.interactions._count");
      var out = {};
      for(i=0; i<count; i++) {
        var id = ProcessValue("cmi.interactions." + i + ".id");
        var type = ProcessValue("cmi.interactions." + i + ".type");
        var response = ProcessValue("cmi.interactions." + i + ".learner_response");
        var interaction = ProcessValue("cmi.interactions." + i + ".result");
        if(response) {
          switch(type) {
            case "performance":
              interaction = response.split(",");
            case "choice":
              interaction = response;
              break;
          }
        }
        out[id] = interaction;
      }
      return out;
    }

   LMS = {
      init: ProcessInitialize,
      end: ProcessFinish,
      value: ProcessValue,
      bookmark: Bookmark,
      status: Status,
      record_reveal: RecordReveal,
      record_page_complete: RecordPageComplete,
      record_single_choice: RecordSingle,
      record_multi_choice: RecordMulti,
      get_progress: GetProgress
   }

  return LMS;
});