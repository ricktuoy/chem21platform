({
	appDir: ".",
    baseUrl: "..",
    dir: "../build",
    paths: {
        jquery: "lib/jquery",
        config: "src/config/main",
        LMS: "src/SCORM-1.2/main",
        "SCO-nav": "src/SCO-nav/main",
        "main-wrapper": "src/main-wrapper"
        "config/urlmap": "src/config/urlmap"
    },
    modules: [
    	{
    		name:"main-wrapper"
    	}
    ],
    optimize: 'none'
})