({
    appDir: ".",
    baseUrl: "..",
    dir: "../build",
    paths: {
        jquery: "lib/jquery",
        "jquery-ui": "lib/jquery-ui",
        config: "src/config/main",
        LMS: "src/SCORM-1.2/main",
        "SCO-nav": "src/SCO-nav/main",
        "main-wrapper": "src/main-wrapper",
        "config/urlmap": "src/config/urlmap",
        "config/pageorder": "src/config/pageorder",
        "config/courseid": "src/config/courseid",
        "uri_js": "lib/uri.js/src",
        "SCO-goals": "src/SCO-goals/main",
        "binhex": "lib/binhex"
    },
    modules: [
        {
            name:"main-wrapper"
        }
    ],
    optimize: 'none',
    shim: {
        "uri_js/jquery.URI": ['jquery', 'uri_js/URI']
    }
})