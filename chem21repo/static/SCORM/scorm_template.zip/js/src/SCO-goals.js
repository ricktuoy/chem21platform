define(["jquery","uri_js/jquery.URI"], function ($) {
  $.fn.SCOGoals = function(links, URLMap, reveals, multichoices, singlechoices, end_id) {
    if(end_id == undefined) {
      end_id="end";
    }
    var $iframe = this;
    var $goals = reveals.add(multichoices).add(singlechoices);
    if($goals.length == 0) {
      $(iframe).trigger("recordSimplePage");
    }
    var click_tracker = function() {
      //initialise interaction IDs
      $goals.each(function(i) {
        $(this).data("scormInteractionID", pageID+"."+i);
      });


      $(this).contents().on("click", links, function(e) {
        var uri = $(this).uri();
        var href = $(this).attr("href");
        var $incomplete_goals = $goals.exclude("*[data-scorm-goal]");
        if($incomplete_goals.length == 0) {
          $(iframe).trigger("recordSimplePage");
        }

        if(!href) {
          return true;
        } 
        if(!(href in URLMap)) {
          if(uri.is("absolute")) {
            window.open(href, "_blank");
          }
          return true;
        }
        var page_id = URLMap[href];
        if( page_id == end_id ) {
          $iframe.trigger("endSCOPage", page_id);
        } else {
          $iframe.trigger("newSCOPage", page_id);
        }
        e.preventDefault();
        e.stopImmediatePropagation();
        return false;
      });

      $(this).contents().on("click", reveals, function(e) {
        var id = $(this).data("scormInteractionID");
        $iframe.trigger("recordReveal", [id]);]
        $(this).data("scormGoal", true);
      });

      $(this).contents().on("mark-complete", multichoices, function(e, responses) {
        var id = $(this).data("scormInteractionID");
        $iframe.trigger("recordMultiChoice", [id, answers]);
        $(this).data("scormGoal", true);
      });

      $(this).contents().on("mark-complete", singlechoices, function(e, response) {
        var id = $(this).data("scormInteractionID");
        $iframe.trigger("recordSingleChoice", [id, answer]);
        $(this).data("scormGoal", true);
      });

      return true;
    };
    $iframe.on("load", click_tracker);
    click_tracker();
  };
  // extending existing object rather than defining something new,
  // return jQuery anyway
  return $;
});