define(["jquery", "config", "jquery-ui", "binhex"], function ($, config) {

  var Progress = function(LMS) {
    this.goal_statuses = {};
    this.page_statuses = {};
    this.LMS = LMS;
    this.confirmed_complete = false;
    this.page_counter = 0;

    this.parse_LMS_string = function(s) {
      var lines = s.split("|");
      var page_hex = lines[0];
      var ret = page_hex.hexToBinary();
      if(!ret['valid']) {
        console.error("First line of LMS string is not valid hex: " + page_hex);
      } else {
        var page_bin = ret['result'];
      }
      do {
        var a = page_bin[0];
        if(a=="0") {
          page_bin = page_bin.substring(1);
        }
      } while(a=="0");
      // start at index 1 to ignore highest-order (zeroth) bit (which is a dummy "1")
      page_bin = page_bin.substring(1);
      for(i=0; i<page_bin.length;  i++) {
        var pageID = config.PageOrder[i];
        if(page_bin[i] == "1") {
          this.page_statuses[pageID] = 1;
        }
      }
      for(l=1; l<lines.length; l++) {
        var parts = lines[l].split(":");
        var scormID = parts[0];
        if(parts[0]) {
          var response = parts[1].split(",");
          this.goal_statuses[scormID] = response;
        }
      }
    };

    this.get_LMS_string = function() {
      var bin = "1";
      // add dummy bit to solve leading zero issues
      console.debug("Generating LMS string");
      for(i=0; i<config.PageOrder.length; i++) {
        var pageID = config.PageOrder[i];
        if(pageID in this.page_statuses) {
          bin += "1";
        } else {
          bin += "0";
        }
      }
      var ret = bin.binaryToHex();
      if(!ret['valid']) {
        return "";
      } else {
        s = ret['result'];
      }
      s += "|";
      var resp_strings = [];
      $.each(this.goal_statuses, function(scormID, response) {
        if($.isArray(response)) {
          resp_strings.push(scormID + ":" + response.join(","));
        } else {
          resp_strings.push(scormID + ":" + response);
        }
      });
      s += resp_strings.join("|");
      return s;
    };

    this.reset_page_counter = function() {
      this.page_counter = 0;
    };

    this.get_first_page_id = function() {
      return config.PageOrder[0];
    };

    this.get_page_id = function(i) {
      if (typeof i === 'undefined') { i = this.page_counter; }
      return config.PageOrder[this.page_counter];
    };

    this.set_page_counter_to_id = function(pageID) {
      this.page_counter = $.inArray(pageID, config.PageOrder);
    }

    this.inc_page_counter = function() {
      this.page_counter++;
      return this.get_page_id();
    };

    this.is_complete_until = function(endID) {
      console.debug("Complete until "+endID);
      var thisID = this.get_page_id();
      do {
        if(!(thisID in this.page_statuses)) {
          this.set_page_counter_to_id(endID);
          return false;
        }
        thisID = this.inc_page_counter();
      } while(thisID != endID)
      return true;
    };

    this.save_to_LMS = function() {
      var s = this.get_LMS_string();
      LMS.value("cmi.suspend_data", s);
    };

    this.set_page_complete = function(pageID) {
      this.page_statuses[pageID] = 1;
    };

    this.set_goal_complete = function(scormID, value) {
      if(value === null) {
        value = 1;
      }
      this.goal_statuses[scormID] = value;
    };

    this.get_goal_status = function(scormID) {
      if(scormID in this.goal_statuses) {
        return this.goal_statuses[scormID];
      } else {
        return null;
      }
    };

    this.is_complete = function() {
      for(i=0; i < config.PageOrder.length; i++ ) {
        var pID = config.PageOrder[i];
        if(!(pID in this.page_statuses)) {
          return false;
        }
      }
      return true;
    };

    this.is_confirmed_complete = function() {
      return this.confirmed_complete;
    }

    if(this.LMS) {
      var s = LMS.value("cmi.suspend_data");
      if(s) {
        this.parse_LMS_string(s);
      } else {
        var base_url = config.alert_uri;
        var user_name = LMS.value("cmi.core.student_id");
        /*
        var url = base_url + config.course_id + "/" + user_name + "?callback=?";
        $.getJSON(url, {'trevor':'giboon'}).done(function(data) {
        }).fail(function(jqxhr, textStatus, error) {
          if(jqxhr.status == 404) { 
          } else {
            var err = $.parseJSON(jqxhr.responseText); 
          }
        });
        */
      }
      var lesson_status = LMS.value("cmi.core.lesson_status");
      if(lesson_status == "completed") {
        this.confirmed_complete = true;
      } else {
        this.confirmed_complete = false;
      }
    }
  }

  var PageStatus = function(pageID, //str 
                            $container,
                            progress // map function
                            ) {
    var w$ = $container[0].contentWindow.$;
    var $container = $container.contents();
    var $reveals = $container.find(config.goals_reveal);
    var $multichoices = $container.find(config.goals_multichoice);
    var $singlechoices = $container.find(config.goals_singlechoice);
    var me = this;


    this.$goals =  $reveals.add($multichoices).add($singlechoices);
    this.$questions = $multichoices.add($singlechoices);
    this.$multichoices = $multichoices;
    this.$reveals = $reveals;
    this.$singlechoices = $singlechoices;
    this.pageID = pageID;
    this.$completed = $();

    this.display = function() {
      console.debug("--  Page status: " + this.pageID);
      console.debug("Goals");
      console.debug(this.$goals);
      console.debug("Questions");
      console.debug(this.$questions);
      console.debug("Multichoices");
      console.debug(this.$multichoices);
      console.debug("Singlechoices");
      console.debug(this.$singlechoices);
      console.debug("Completed");
      console.debug(this.$completed);
    };

    this.is_reveal = function($goal) {
      return this.$reveals.is($goal);
    };

    this.is_multichoice = function($goal) {
      return this.$multichoices.is($goal); 
    };

    this.is_singlechoice = function($goal) {
      return this.$singlechoices.is($goal);
    };

    this.load_user_response = function($goal, response) {
      var deferred = [];
      if(response.length > 0 && (this.is_multichoice($goal) || this.is_singlechoice($goal))) {
        w$.each(response, function(i, v) {
          var $i = $goal.find("input[value='" + v + "']");
          $i.trigger("click");
        });
        $goal.addClass("preloaded");
        $goal.trigger("mark");
      } else if (this.is_reveal($goal)) {
        $goal.addClass("completed");
      }
    };

    w$(".quiz_questions").on("marking-done", ".question.preloaded", function() {
      var $a = w$(this).find("a.next, a.submit");
      $a.trigger("click");
    });

    this.is_goal_complete = function($goal) {
      return this.$completed.is($goal);
    };

    this.is_complete = function() {
      var $incomplete = this.$goals.not(this.$completed);
      return ($incomplete.length == 0);
    };

    this.set_complete = function($goal) {
      this.$completed = this.$completed.add($goal);
    };

    this.get_scorm_id = function($goal) {
      if(this.is_reveal($goal)) {
        return this.pageID + "." + "r" + this.$reveals.index($goal);
      }
      return this.pageID + "." + $goal.data("id");
    };

    this.get_user_response = function($goal) {
      if(this.is_multichoice($goal) || this.is_singlechoice($goal)) {
        if( !this.is_goal_complete($goal) || $goal.is(".skipped") ) {
          return [];
        }
        var out = [];
        $goal.find("input:checked").each(function() {
          out.push($(this).val());
        });
        return out;
      } 
      return null;
    };

    this.get_nav_links = function() {
      return $container.find("#class_nav li");
    };

    this.get_id_from_nav_link = function($li, $lis) {
      var $a = $li.find(">a");
      if($a.length>0) {
        var href = $a.attr("href");
        if(href in config.URLMap) { 
          return config.URLMap[href];
        }
      } else {
        var start_index = $lis.index($li);
        var offset = 0;
        var $a = null;
        do {
          offset++;
          var $this_li = $lis.eq(start_index + offset);
          if($this_li.length == 0 ) {
            console.debug("Fallen off the bottom .... !!!!!");
            return "end";
          }
          $a = $this_li.find(">a");
        } while($a.length == 0)
        var href = $a.attr("href");
        if(href in config.URLMap) { 
          var nextPageID = config.URLMap[href];
          var index = $.inArray(nextPageID, config.PageOrder);
          return config.PageOrder[index-offset];
        }
      }
      return undefined;
    };

    function mark_nav_links() {
      progress.reset_page_counter();
      var $lis = me.get_nav_links()
      $lis.each(function(i) {
        var $this = $(this);
        var $next = $lis.eq(i+1);
        var pageID = progress.get_page_id();
        if($next) {
          var $next_next = $lis.eq(i+2);
          var nextPageID = me.get_id_from_nav_link($next, $lis);
          console.debug("Checking complete from " + pageID +" to " + nextPageID);
          if(progress.is_complete_until(nextPageID)) {
            $(this).addClass("SCORM-complete");
          }
        } else {
          console.debug("Checking complete just for " + pageID);
          if(pageID in progress.page_statuses) {
            $(this).addClass("SCORM-complete");
          }
        }
      });
      var $reverse_actives = $($lis.filter(".active").has("li").get().reverse());

      $reverse_actives.each(function(i) {
        var $this = $(this);
        var pageID = me.get_id_from_nav_link($this, $lis);
        if(pageID in progress.page_statuses && $this.find("li:not(.SCORM-complete)").length == 0) {
          $this.addClass("SCORM-complete");
        } else {
          $this.removeClass("SCORM-complete");
        }
      });
    };

    mark_nav_links();

    this.$goals.each(function() {
      var scormID = me.get_scorm_id($(this));
      $(this).data("scormID", scormID);
      var response = progress.get_goal_status(scormID);
      if(response) {
        me.set_complete($(this));
        // make sure the jQuery object originating in *the iframe* is passed in (w$)
        me.load_user_response(w$(this), response);
      }
    });

  };

  $.fn.SCOGoals = function(LMS) {
    var $iframe = this;
    var progress = new Progress(LMS);
    var goal_tracker = function(e, pageID, end) {
      var $content = $(this).contents().find("#content");

      var page_status = new PageStatus(pageID, $iframe, progress);
      //page_status.display();
      if(page_status.is_complete()) {
        progress.set_page_complete(pageID);
      }
      if(progress.is_confirmed_complete()) {
        var $complete = $("<p class=\"course_completed\">You have finished this part of the course.</p>");
        var $titlebar = $content.find("#quiz_progress");
        if($titlebar.length > 0) {
          $titlebar.after($complete);
        } else {
          $content.prepend($complete);
        }         
      }

      var goal_complete = function($goal) {
        console.debug("Goal completed");
        console.debug($goal);
        var scormID = page_status.get_scorm_id($goal);
        console.debug("SCORM id "+scormID);
        page_status.set_complete($goal);
        progress.set_goal_complete(scormID, 
          page_status.get_user_response($goal));
        if(page_status.is_complete()) {
          progress.set_page_complete(pageID);
        }
      }
      var $quiz = $(this).contents().find(".quiz_questions");
      var $content = $(this).contents().find("#content");
      console.debug($quiz);
      console.debug($content);
      $content.on("click", "a.hide_solution", function(e) { goal_complete($(this)); });
      $quiz.on("click", ".question .next", function(e) { 
          console.debug("Next question");
          var $q = $(this).closest(".question");
          goal_complete($(this).closest($q)); 
        });
      console.debug("Set event handlers");
      return true;
    };

    var end_tracker = function(e, pageID) {
      var $content = $(this).contents().find("#content");
      var $end_nav = $content.find("#end-nav");
      if(config.course_id == "greencpd-sss-topic-2") {
        var $message = $("<p style=\"font-weight: bold\">You've completed the course!</p><p>We hope you have enjoyed your studies.</p><p>Course administrators have been notified you have finished.  They will be in touch with you soon to arrange taking your feedback and issuing your certificate.</p><p>You can now close this window.</p>");
        var button_txt = "course";
      } else {
        var button_txt = "part 1";
        var $message = $("<p style=\"font-weight: bold\">You've completed this part of the course!</p><p>Please close this window to return to Administrate and continue with the next part.</p>");
      }
      if(!progress.is_confirmed_complete()) {
        var $a = $("<a />").addClass("next").attr("id", "finish-course").attr("href","#").text("Finish " + button_txt);
        $end_nav.append($a);
      }
      $content.on("click", "a#finish-course", function(e) {
        e.preventDefault();
        e.stopImmediatePropagation();
        var $this = $(this);
        var done = function() {
          /*
          var base_url = config.alert_uri;
          var user_name = LMS.value("cmi.core.student_id");
          var url = base_url + config.course_id + "/" + user_name + "?callback=?";
          $.getJSON(url, {'trevor':'arnd'}).done(function(data) {
            $content.empty();
            $content.append($message);            
          }).fail(function(jqxhr, textStatus, error) {
            var fail_message = "End alert failed (" + url + "). Error "+ jqxhr.status;
            if(jqxhr.status == 404) {
              fail_message += "404 error. Probably username is not known format.";
            } else {
              var err = $.parseJSON(jqxhr.responseText); 
              fail_message += "Error " + error + ": " + err['message'];
            }
          });
          */          
        };
        if(progress.is_complete()) {
          //done();
        } else {
          $("#dialog-finish-confirm").show();
          $("#dialog-finish-confirm").dialog({
            resizable: false,
            height: "auto",
            width: 400,
            modal: true,
            buttons: {
              "Yes, I've finished the course": function() {
                progress.confirmed_complete = true;
                done();
                $( this ).dialog( "close" );
              },
              Cancel: function() {
                $( this ).dialog( "close" );
              }
            }
          });
        }

      });
    };
    
    $iframe.on("newSCOPageLoaded", goal_tracker);
    $iframe.on("endSCOPageLoaded", goal_tracker);
    $iframe.on("endSCOPageLoaded", end_tracker);
    return progress;
  };
});