define(["jquery", "config", "LMS", "SCO-nav"], function($, config, LMS, nav) {

    $("document").ready(function() {

        
        var currentPage = null;
        var reachedEnd = false;
        var $iframe = $("#contentFrame");

        function resizeIframe(obj) {
            console.debug("IFrame loaded, attempting resize");
            console.debug(obj.contentWindow.document);
            obj.style.height = obj.contentWindow.document.body.scrollHeight + 'px';
            return true;
        }

        function resizeIframeCb() {
            resizeIframe(this);
        }

        function getPageSrcFromId(page_id) {
            return "../pages/" + page_id + ".html"
        }

        function handleNewPage(e, page_id) {
            LMS.bookmark(page_id);
            currentPage = getPageSrcFromId(page_id);
            $iframe.attr("src", currentPage);
        }

        function handleLastPage(e, page_id) {
            reachedEnd = true;
            handleNewPage(e, page_id);
        }

        function handleUnload() {
            LMS.end(reachedEnd);
        }

        //get the iFrame sized correctly and set up
        $iframe.css("border",0);    
        $iframe.on("newSCOPage", handleNewPage);
        $iframe.on("endSCOPage", handleLastPage);
        $iframe.on("load", resizeIframeCb);
        $(window).on("unload", handleUnload);
        resizeIframe($iframe[0]); 

        //initialize communication with the LMS
        LMS.init();
        var bookmark = LMS.bookmark();
        currentPage = getPageSrcFromId(bookmark || "start");
        $iframe.attr("src", currentPage);
        $iframe.SCONav(config.nav_link_selector, config.URLMap);
    });
    return null;
});