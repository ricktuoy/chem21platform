define(["jquery", "config", "LMS", "SCO-nav", "SCO-goals"], function($, config, LMS, nav, GoalStatus) {

    $("document").ready(function() {      
        var currentPage = null;
        var pageID = null;
        var reachedEnd = false;
        var $iframe = $("#contentFrame");
        var $dialogs = $(".dialog");
        var completedGoals = {};
        var completedPages = {};
        var progress;

        $dialogs.hide();

        function getCurrentPage() {
            return currentPage;
        }

        function getProgress() {
            return completedGoals;
        }

        function resizeIframe(obj, height) {
            obj.height(height);
            return true;
        }

        function resizeIframeCb() {
            var obj = this;
            console.debug("Triggering 'new page loaded' event");
            if(reachedEnd) {
                $(this).trigger("endSCOPageLoaded", [pageID]);
            } else {
                $(this).trigger("newSCOPageLoaded", [pageID]);
            }
            window.moveTo(0,0);
            window.resizeTo(
                window.screen.availWidth,
                window.screen.availHeight
            );
        }

        function getPageSrcFromId(page_id) {
            return "../pages/" + page_id + ".html";
        }

        function handleNewPage(e, page_id, end) {
            if(end) {
                reachedEnd = true;
            } else {
                reachedEnd = false;
            }
            LMS.bookmark(page_id);
            pageID = page_id;
            currentPage = getPageSrcFromId(pageID);
            $iframe.attr("src", currentPage);
        }

        function handleLastPage(e, page_id) {
            handleNewPage(e, page_id, true);
        }

        function handleUnload(e) {
            e.preventDefault();
            e.stopImmediatePropagation();
            console.debug("Before unload handle ...");
            console.debug("Saving to LMS");
            progress.save_to_LMS();
            LMS.end(progress.is_confirmed_complete());
            return true;
        }

        $("body").css("margin", 0);
        $("body").css("padding", 0);

        //get the iFrame sized correctly and set up
        $iframe.css("border",0);
        $iframe.on("newSCOPage", handleNewPage);
        $iframe.on("endSCOPage", handleLastPage);
        $iframe.on("load", resizeIframeCb);

        $(window).on("unload", handleUnload);
        $(window).on("resize", function() {
            resizeIframe($iframe, $(this).height());
        });
        console.debug("initialize LMS");
        //initialize communication with the LMS
        LMS.init();
        console.debug("Student ID: " + LMS.value("cmi.core.student_id"));
        console.debug("Student name: " + LMS.value("cmi.core.student_name"));
        console.debug("Launch data: " + LMS.value("cmi.launch_data"));
        console.debug("Suspend data: " + LMS.value("cmi.suspend_data"));
        console.debug("Entry data: " + LMS.value("cmi.core.entry"));
        console.debug("get progress");
        completedGoals = LMS.get_progress();
        console.debug("LMS bookmarks");
        var bookmark = LMS.bookmark();
        console.debug("Current page");
        pageID = bookmark || "start";
        currentPage = bookmark || "start";
        console.debug("Set up nav");
        $iframe.SCONav(config.nav_link_selector, config.inline_link_selector, config.URLMap);
        console.debug("Set up goals");
        progress = $iframe.SCOGoals(LMS);
        console.debug("Load page");
        $iframe.trigger("newSCOPage", [pageID]);
    });
    return null;
});