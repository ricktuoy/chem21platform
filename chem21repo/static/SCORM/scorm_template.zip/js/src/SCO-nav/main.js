define(["jquery"], function ($) {
  $.fn.SCONav = function(links, URLMap, end_id) {
    if(end_id == undefined) {
      end_id="end";
    }
    var $iframe = this;
    var click_tracker = function() {
      $(this).contents().on("click", links, function(e) {
        var href = $(this).attr("href");
        console.debug("Nav link clicked");
        if(!href) {
          console.debug("no href");
          return true;
        } 
        if(!(href in URLMap)) {
          console.debug("href not in URL map");
          return true;
        }
        var page_id = URLMap[href];
        if( page_id == end_id ) {
          $iframe.trigger("endSCOPage", page_id);
          console.debug("Triggered end page event");
        } else {
          $iframe.trigger("newSCOPage", page_id);
          console.debug("Triggered new page event: "+page_id);
        }
        e.preventDefault();
        e.stopImmediatePropagation();
        return false;
      });
      return true;
    };
    $iframe.on("load", click_tracker);
    click_tracker();
  };
  
  // extending existing object rather than defining something new,
  // return jQuery anyway
  return $;
});