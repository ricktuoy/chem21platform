  define(["jquery","uri_js/jquery.URI"], function ($) {
  $.fn.SCONav = function(nav_links, inline_links, URLMap, end_id) {
    if(end_id == undefined) {
      end_id="end";
    }
    var $iframe = this;
    var click_tracker = function() {
      var load_internal_link = function(href) {
        var page_id = URLMap[href];
        if( page_id == end_id ) {
          $iframe.trigger("endSCOPage", page_id);
        } else {
          $iframe.trigger("newSCOPage", page_id);
        }
      };

      $(this).contents().on("click", inline_links, function(e) {
        console.debug("Checkgin for inline click: ");
        console.debug($(this));
        var href = $(this).attr("href");
        if(!(href in URLMap)) {
          var uri = $(this).uri();
          if(uri.is("absolute")) {
            window.open(href, "_blank");
          }
          return true;
        } else {
          load_internal_link(href);
        }
      });

      $(this).contents().on("click", nav_links, function(e) {
        var href = $(this).attr("href");
        if(!href) {
          return true;
        }
        if(href in URLMap) {
          load_internal_link(href);
        }
        e.preventDefault();
        e.stopImmediatePropagation();
        return false;
      });
      return true;
    };
    $iframe.on("load", click_tracker);
  };
  // extending existing object rather than defining something new,
  // return jQuery anyway
  return $;
});