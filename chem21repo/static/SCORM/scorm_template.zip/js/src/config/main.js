define(["config/urlmap", "config/pageorder", "config/courseid"], function(URLMap, PageOrder, courseID) {
	var config = {
		nav_link_selector: "nav a, div#class_nav a",
		inline_link_selector: "#content p a, #content li a, #content td a, #content th a",
		goals_reveal: "a.hide_solution",
		goals_multichoice: ".question[data-type=\"multi\"]",
		goals_singlechoice: ".question[data-type=\"single\"]",
		URLMap: URLMap,
		PageOrder: PageOrder,
		course_id: courseID,
		alert_uri: "https://greencpd.herokuapp.com/scorm/user_event/"
	};
	return config;
});