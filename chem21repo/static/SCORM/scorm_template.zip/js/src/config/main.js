define(["config/urlmap"], function(URLMap) {
	var config = 
	{
		nav_link_selector: "nav a, div#class_nav a",
		URLMap: URLMap
	};
	return config;
});