define([], function() {
	var config = 
	{
		nav_link_selector: "nav a",
		URLMap: {
			"": "index",
			"": "page1",
			"": "page2",
			"": "end"
		}
	};
	return config;
});