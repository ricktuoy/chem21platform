define(function() {
	return {
			"/methods-of-facilitating-change/tools-and-guides/": "start",
			"/methods-of-facilitating-change/tools-and-guides/the-need-fo-solvent-selection-guides/": "page1",
			"/methods-of-facilitating-change/tools-and-guides/criteria-for-solvent-selection/": "page2",
			"/methods-of-facilitating-change/tools-and-guides/criteria-for-solvent-selection/self-assessment-questions/": "end"
		}
});