define(["jquery", "config", "LMS", "SCO-nav"], function($, config, LMS, nav) {
    console.debug($);
    console.debug(config);
    console.debug(LMS);
    console.debug(nav);
    $("document").ready(function() {

        
        var currentPage = null;
        var reachedEnd = false;
        var $iframe = $("#contentFrame");

        function resizeIframe() {
            var obj = this;
            console.debug("IFrame loaded, attempting resize");
            obj.style.height = obj.contentWindow.document.body.scrollHeight + 'px';
            return true;
        }

        function getPageSrcFromId(page_id) {
            return "../pages/" + page_id + ".html"
        }

        function handleNewPage(e, page_id) {
            LMS.bookmark(page_id);
            currentPage = getPageSrcFromId(page_id);
            $iframe.attr("src", currentPage);
        }

        function handleLastPage(e, page_id) {
            reachedEnd = true;
            handleNewPage(e, page_id);
        }

        function handleUnload() {
            LMS.end(reachedEnd);
        }

        //get the iFrame sized correctly and set up
        $iframe.css("border",0);    
        $iframe.on("newSCOPage", handleNewPage);
        $iframe.on("endSCOPage", handleLastPage);
        $iframe.on("load", resizeIframe);
        $(window).on("unload", handleUnload);

        //initialize communication with the LMS
        LMS.init();
        var bookmark = LMS.bookmark();
        currentPage = getPageSrcFromId(bookmark || "start");
        $iframe.attr("src", currentPage);
        $iframe.SCONav(config.nav_link_selector, config.URLMap);
    });
    return null;
});