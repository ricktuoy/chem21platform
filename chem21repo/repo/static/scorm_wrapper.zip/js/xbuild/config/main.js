define('config',[],function() {
	var config = 
	{
		nav_link_selector: "nav a, div#class_nav a",
		URLMap: {
			"/methods-of-facilitating-change/tools-and-guides/": "start",
			"/methods-of-facilitating-change/tools-and-guides/the-need-fo-solvent-selection-guides/": "page1",
			"/methods-of-facilitating-change/tools-and-guides/criteria-for-solvent-selection/": "page2",
			"/methods-of-facilitating-change/tools-and-guides/criteria-for-solvent-selection/self-assessment-questions/": "end"
		}
	};
	return config;
});
